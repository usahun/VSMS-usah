//
//  MyAccountController.swift
//  VSMS
//
//  Created by usah on 3/20/19.
//  Copyright © 2019 121. All rights reserved.
//

import UIKit

class MyAccountController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func backbtnpress(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
  
   
}
