//
//  APIModel.swift
//  VSMS
//
//  Created by Vuthy Tep on 7/4/19.
//  Copyright © 2019 121. All rights reserved.
//

import Foundation

struct Category {
    var ID: Int
    var cat_Name: String
    var cat_Name_KH: String
}
