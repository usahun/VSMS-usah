//
//  HomeCollectionViewCell.swift
//  VSMS
//
//  Created by Rathana on 3/14/19.
//  Copyright © 2019 121. All rights reserved.
//

import UIKit

class HomeCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var ImageCollection: UIImageView!
    @IBOutlet weak var ContentTitle: UILabel!
    @IBOutlet weak var CurrentPriceLabel: UILabel!
    @IBOutlet weak var OldPriceLabel: UILabel!
}
