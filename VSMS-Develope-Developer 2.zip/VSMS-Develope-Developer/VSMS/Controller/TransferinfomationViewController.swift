//
//  TransferinfomationViewController.swift
//  VSMS
//
//  Created by usah on 4/4/19.
//  Copyright © 2019 121. All rights reserved.
//

import UIKit

class TransferinfomationViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func btnback(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    

}
