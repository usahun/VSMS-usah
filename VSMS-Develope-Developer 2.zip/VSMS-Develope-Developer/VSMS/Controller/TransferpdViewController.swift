//
//  TransferpdViewController.swift
//  VSMS
//
//  Created by usah on 3/25/19.
//  Copyright © 2019 121. All rights reserved.
//

import UIKit

class TransferpdViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
    }
  
    
}
