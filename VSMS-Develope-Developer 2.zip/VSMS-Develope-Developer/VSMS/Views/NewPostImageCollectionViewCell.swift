//
//  NewPostImageCollectionViewCell.swift
//  VSMS
//
//  Created by Rathana on 6/28/19.
//  Copyright © 2019 121. All rights reserved.
//

import UIKit

class NewPostImageCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var Image: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
