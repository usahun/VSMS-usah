//
//  ImageCollectionViewCell.swift
//  VSMS
//
//  Created by Vuthy Tep on 5/18/19.
//  Copyright © 2019 121. All rights reserved.
//

import UIKit

class ImageCollectionViewCell: UICollectionViewCell {

    
    @IBOutlet weak var productImageView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
