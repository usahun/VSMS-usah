//
//  MapTableViewHeaderFooterView.swift
//  VSMS
//
//  Created by Vuthy Tep on 5/18/19.
//  Copyright © 

import UIKit


class MapTableViewHeaderFooterView: UITableViewHeaderFooterView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
