//
//  ImgeSlideCollectionViewCell.swift
//  VSMS
//
//  Created by usah on 6/9/19.
//  Copyright © 2019 121. All rights reserved.
//

import UIKit

class ImgeSlideCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var Slideshow: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        
      
    }
    
}
    

